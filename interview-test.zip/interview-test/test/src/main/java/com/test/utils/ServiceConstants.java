package com.test.utils;

public class ServiceConstants {

    public static final String INGREDIENT_1 = "2/3 cup (142g) light brown sugar, packed";
    public static final String INGREDIENT_2 = "2/3 cup (131g) granulated sugar";
    public static final String INGREDIENT_3 = "8 tablespoons (113g) unsalted butter";
    public static final String INGREDIENT_4 = "1/2 cup (92g) vegetable shortening";

    public static final String INSTRUCTION_1 = "Preheat the oven to 375°F. Lightly grease (or line with parchment) two baking sheets";
    public static final String INSTRUCTION_2 = "In a large bowl, combine the sugars, butter, shortening, salt, vanilla and almond extracts, vinegar, and baking soda, beating until smooth and creamy";
    public static final String INSTRUCTION_3 = "Beat in the egg, again beating until smooth. Scrape the bottom and sides of the bowl with a spatula to make sure everything is thoroughly combined";
    public static final String INSTRUCTION_4 = "Mix in the flour, then the chips";
}
