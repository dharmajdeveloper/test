package com.test.service;

import com.test.dto.TestResponse;

public interface TestService {

    public TestResponse getResponse();
}
