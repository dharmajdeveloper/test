package com.test.controller;

import com.test.dto.TestResponse;
import com.test.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @Autowired
    private TestService service;

    @PostMapping("scrape")
    public TestResponse getScrape() {
        return service.getResponse();
    }
}