package com.test.service.impl;

import com.test.dto.Recipe;
import com.test.dto.TestResponse;
import com.test.service.TestService;
import org.springframework.stereotype.Service;

import java.util.Arrays;

import static com.test.utils.ServiceConstants.*;

@Service
public class TestServiceImpl implements TestService {
    @Override
    public TestResponse getResponse() {
        return TestResponse.builder().recipe(
                Recipe.builder()
                        .ingredients(Arrays.asList(INGREDIENT_1
                                , INGREDIENT_2, INGREDIENT_3, INGREDIENT_4))
                        .instructions(Arrays.asList(INSTRUCTION_1, INSTRUCTION_2, INSTRUCTION_3, INSTRUCTION_4))
                        .build()
        ).build();
    }
}
